# CAMPUS GEAR — Starter project

1. Install Node.js 20 or newer.
2. Run npm install, then npm run reset.
3. Run npm run dev and open http://localhost:5173.
4. Use npm test for the supplied practice checks.

API: http://localhost:3000. Demo password: Campus123!

Read EXAM_REQUIREMENTS.md. The reference website and screenshot are under reference/ in the downloadable exam package. Some pages and business rules are intentionally TODO. The JSON data store is already set up; this exercise does not need Docker, XAMPP or a database server.