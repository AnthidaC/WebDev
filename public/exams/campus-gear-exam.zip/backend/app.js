const express = require('express'); const cors = require('cors');
const app = express(); app.use(cors()); app.use(express.json());
app.get('/api/health',(req,res)=>res.json({ok:true}));
app.use('/api',require('./routes/api.js'));
app.use((req,res)=>res.status(404).json({message:'ไม่พบเส้นทาง'}));
app.use((error,req,res,next)=>{res.status(error.status || 500).json({message:error.status?error.message:'เกิดข้อผิดพลาดในระบบ'});});
module.exports = app;
