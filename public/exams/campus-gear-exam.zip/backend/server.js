require('dotenv').config();
const app = require('./app.js');
app.listen(process.env.PORT || 3000, '0.0.0.0', () => console.log('CAMPUS GEAR API ready'));
