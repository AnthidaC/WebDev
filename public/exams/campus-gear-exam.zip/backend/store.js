// Storage adapter is PROVIDED. Updates are synchronous and persisted atomically.
const fs = require('node:fs'); const path = require('node:path');
const file = process.env.EXAM_DB_FILE || path.join(__dirname, 'data/db.json');
function save(db) { fs.mkdirSync(path.dirname(file), {recursive:true}); fs.writeFileSync(file + '.tmp', JSON.stringify(db, null, 2)); fs.renameSync(file + '.tmp', file); }
function read() { if (!fs.existsSync(file)) save(require('./seed.js')()); return JSON.parse(fs.readFileSync(file,'utf8')); }
function update(callback) { const db = read(); const result = callback(db); if(result && typeof result.then === 'function') throw new Error('Store callback must be synchronous'); save(db); return result; }
module.exports = { read, update };
