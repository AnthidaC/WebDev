const bcrypt = require('bcryptjs');
const { today, offset } = require('./lib/dates.js');
module.exports = function seed() {
  const date = today();
  const users = [
    { id: 1, name: 'Admin Campus', email: 'admin@campus.test', role: 'admin' },
    { id: 2, name: 'Mali Jaidee', email: 'mali@campus.test', role: 'student' },
    { id: 3, name: 'Niran Studio', email: 'niran@campus.test', role: 'student' },
  ].map(user => ({ ...user, passwordHash: bcrypt.hashSync('Campus123!', 10) }));
  const equipment = [
    { id: 1, name: 'Sony Alpha A7 IV', category: 'Camera', code: 'CAM-001', stock: 4, deposit: 1500, description: 'กล้อง Mirrorless สำหรับงานภาพนิ่งและวิดีโอ พร้อมเลนส์มาตรฐานและกระเป๋า', icon: 'camera', tone: 'lavender' },
    { id: 2, name: 'Manfrotto Tripod', category: 'Accessories', code: 'ACC-002', stock: 6, deposit: 300, description: 'ขาตั้งกล้องปรับระดับได้ เหมาะกับงานสัมภาษณ์และถ่ายภาพในสตูดิโอ', icon: 'tripod', tone: 'sand' },
    { id: 3, name: 'Epson Projector', category: 'Presentation', code: 'PRE-003', stock: 3, deposit: 800, description: 'โปรเจกเตอร์สำหรับห้องเรียนและกิจกรรม พร้อมสาย HDMI', icon: 'projector', tone: 'mint' },
    { id: 4, name: 'Rode Wireless GO II', category: 'Audio', code: 'AUD-004', stock: 2, deposit: 500, description: 'ไมโครโฟนไร้สายสองตัว พร้อมตัวรับและชุดสายเชื่อมต่อ', icon: 'mic', tone: 'blue' },
    { id: 5, name: 'LED Studio Light', category: 'Lighting', code: 'LGT-005', stock: 5, deposit: 400, description: 'ไฟ LED ปรับความสว่างและอุณหภูมิสีได้ พร้อมขาตั้ง', icon: 'light', tone: 'peach' },
    { id: 6, name: 'JBL Portable Speaker', category: 'Audio', code: 'AUD-006', stock: 4, deposit: 500, description: 'ลำโพงพกพาสำหรับกิจกรรมขนาดเล็ก พร้อมสายชาร์จ', icon: 'speaker', tone: 'rose' },
  ];
  const bookings = [
    { id: 1, equipmentId: 1, equipmentName: equipment[0].name, userId: 2, userName: users[1].name, quantity: 1, from: offset(date, 1), to: offset(date, 2), deposit: 1500, status: 'approved', createdAt: new Date().toISOString() },
    { id: 2, equipmentId: 3, equipmentName: equipment[2].name, userId: 2, userName: users[1].name, quantity: 1, from: offset(date, 4), to: offset(date, 5), deposit: 800, status: 'pending', createdAt: new Date().toISOString() },
    { id: 3, equipmentId: 2, equipmentName: equipment[1].name, userId: 2, userName: users[1].name, quantity: 1, from: date, to: date, deposit: 300, status: 'cancelled', createdAt: new Date().toISOString() },
    { id: 4, equipmentId: 1, equipmentName: equipment[0].name, userId: 3, userName: users[2].name, quantity: 1, from: offset(date, 1), to: offset(date, 1), deposit: 1500, status: 'pending', createdAt: new Date().toISOString() },
  ];
  return { users, equipment, bookings, nextUser: 4, nextEquipment: 7, nextBooking: 5 };
};
