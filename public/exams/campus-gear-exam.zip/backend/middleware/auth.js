const jwt = require('jsonwebtoken'); const store = require('../store.js');
const key = () => process.env.JWT_KEY || 'campus-gear-local-practice-key';
function auth(req,res,next) {
  const header = req.get('Authorization') || '';
  if(!header.startsWith('Bearer ')) return res.status(401).json({message:'กรุณาเข้าสู่ระบบ'});
  let token; try { token = jwt.verify(header.slice(7), key()); } catch { return res.status(401).json({message:'Token ไม่ถูกต้องหรือหมดอายุ'}); }
  const user = store.read().users.find(user => user.id === token.userId);
  if(!user) return res.status(401).json({message:'ไม่พบบัญชีผู้ใช้'});
  req.user = {id:user.id,name:user.name,email:user.email,role:user.role}; next();
}
function admin(req,res,next) { auth(req,res,()=>req.user.role==='admin'?next():res.status(403).json({message:'เฉพาะผู้ดูแลระบบ'})); }
module.exports = { auth, admin, key };
