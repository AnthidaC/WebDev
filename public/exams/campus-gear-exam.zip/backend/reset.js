const store = require('./store.js'); const seed = require('./seed.js');
store.update(db => { for(const key of Object.keys(db)) delete db[key]; Object.assign(db, seed()); });
console.log('Practice data reset. Password for demo accounts: Campus123!');
