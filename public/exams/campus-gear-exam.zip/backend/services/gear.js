// TODO R04/R05/R06/R07/R08: implement business rules here.
const {fail}=require('../lib/errors.js'); const {today}=require('../lib/dates.js');
const todo=()=>fail(501,'ยังไม่ได้พัฒนา business rules');
exports.today=today;
exports.active=booking=>['pending','approved'].includes(booking.status);
exports.available=()=>0;
exports.validateEquipment=todo;
exports.peak=todo;
exports.book=todo;
exports.cancel=todo;
exports.changeStatus=todo;
