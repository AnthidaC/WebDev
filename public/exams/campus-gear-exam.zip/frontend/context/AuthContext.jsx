import {createContext,useContext,useState,useEffect} from 'react';import {api} from '../lib/api';
const Context=createContext(null);
export function AuthProvider({children}){
  const [user,setUser]=useState(null);const [loading,setLoading]=useState(true);
  function logout(){sessionStorage.removeItem('gear-token');setUser(null);}
  useEffect(()=>{if(sessionStorage.getItem('gear-token'))api('/auth/me').then(setUser).catch(logout).finally(()=>setLoading(false));else setLoading(false);window.addEventListener('gear-unauthorized',logout);return()=>window.removeEventListener('gear-unauthorized',logout);},[]);
  async function login(email,password){const result=await api('/auth/login',{method:'POST',body:{email,password}});sessionStorage.setItem('gear-token',result.token);setUser(result.user);}
  return <Context.Provider value={{user,loading,login,logout}}>{children}</Context.Provider>;
}
export const useAuth=()=>useContext(Context);
