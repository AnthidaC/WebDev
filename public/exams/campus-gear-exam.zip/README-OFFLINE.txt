CAMPUS GEAR — OFFLINE EXAM PACK

1. Extract this ZIP. Open EXAM_REQUIREMENTS.md and reference/index.html.
2. reference/campus-gear-target.png is the target screenshot.
3. Run npm install, npm run reset, npm run dev, npm test.
4. The supplied package files are the starter project. Do not replace them with the reference preview.
5. Demo password: Campus123! (admin@campus.test, mali@campus.test, niran@campus.test).

This practice exam stores data in a local JSON file; it does not require Docker, XAMPP, or a database server.